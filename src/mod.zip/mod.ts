/* eslint-disable @typescript-eslint/naming-convention */
import { DependencyContainer } from "tsyringe";
import { IPreAkiLoadMod } from "@spt-aki/models/external/IPreAkiLoadMod";
import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { ILogger } from "@spt-aki/models/spt/utils/ILogger";
import { PreAkiModLoader } from "@spt-aki/loaders/PreAkiModLoader";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { ImageRouter } from "@spt-aki/routers/ImageRouter";
import { ConfigServer } from "@spt-aki/servers/ConfigServer";
import { ConfigTypes } from "@spt-aki/models/enums/ConfigTypes";
import { ITraderAssort, ITraderBase } from "@spt-aki/models/eft/common/tables/ITrader";
import { ITraderConfig, UpdateTime } from "@spt-aki/models/spt/config/ITraderConfig";
import { JsonUtil } from "@spt-aki/utils/JsonUtil";
import { Item } from "@spt-aki/models/eft/common/tables/IItem";
import { IDatabaseTables } from "@spt-aki/models/spt/server/IDatabaseTables";
import * as baseJson from "../db/superammotrader.json";
import * as assortJson from "../db/assort.json";

class VafelsTrader implements IPreAkiLoadMod, IPostAkiLoadMod, IPostDBLoadMod {
    mod: string;
    logger: ILogger;
    private modConfig = require("../config/config.json");
    constructor() {
        this.mod = "VAFELZ-ALLAMMO";
    }
    public preAkiLoad(container: DependencyContainer): void {
        this.logger = container.resolve<ILogger>("WinstonLogger");
        this.registerProfileImage(container);
        this.setupTraderUpdateTime(container);
    }
    public postDBLoad(container: DependencyContainer): void {
        const db = container.resolve<DatabaseServer>("DatabaseServer").getTables();
        const JsonUtil = container.resolve<DatabaseServer>("JsonUtil");
        db.traders[baseJson._id] = {
            assort: this.createAssortTable(),
            base: JsonUtil.deserialize(JsonUtil.serialize(baseJson)) as ITraderBase,
            questassort: undefined
        };
        this.addTraderToLocales(db, baseJson.name, "", baseJson.nickname, baseJson.location, "UwU");
    }
    private registerProfileImage(container: DependencyContainer): void {
        const PreAkiModLoader = container.resolve<PreAkiModLoader>("PreAkiModLoader");
        const imageFilePath = `./${PreAkiModLoader.getModPath(this.mod)}res`;
        const ImageRouter = container.resolve<ImageRouter>("ImageRouter");
        imageRouter.addRoute(baseJson.avatar.replace(".jpg", ""), `${imageFilePath}/vafelz.jpg`);
    }
    private setupTraderUpdateTime(container: DependencyContainer): void {
        const configServer = container.resolve<ConfigServer>("ConfigServer");
        const traderConfig = configServer.getConfig<ITraderConfig>(ConfigTypes.TRADER);
        const traderRefreshConfig: UpdateTime = {traderId: baseJson._id, seconds: 3600};
        traderConfig.updateTime.push(traderRefreshConfig);
    }
    private addTraderToLocales(tables: IDatabaseTables, fullName: string, firstName: string, nickName: string, location: string, description: string) {
        const locales = Object.values(tables.locales.global) as Record<string,string>[];
        for (const local of locales) {
            locale[`${baseJson._id} Fullname`] = fullName;
            locale[`${baseJson._id} FirstName`] = firstName;
            locale[`${baseJson._id} Nickname`] = nickName;
            locale[`${baseJson._id} Location`] = location;
            locale[`${baseJson._id} Description`] = description;
        }
    }
    private createAssortTable(): ITraderAssort {
        const assortTable: ITraderAssort = {
            barter_scheme: {},
            items: [],
            loyal_level_items: {},
            nextResupply: 0
        };
        const ROUBLE_ID = "5449016a4bdc2d6f028b456f";

        // 12x70MM BUCKSHOT
        // 5.25mm Buckshot
        const vaf12x70525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70525buckshot);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 8.5mm Magnum Buckshot
        const vaf12x7085magnum: Item = {
            _id: "5d6e6806a4b936088465b17e",
            _tpl: "5d6e6806a4b936088465b17e",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x7085magnum);
        assortTable.barter_scheme["5d6e6806a4b936088465b17e"] = [
            [
                {
                    count: 106
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 7mm Buckshot
        const vaf12x707buckshot: Item = {
            _id: "560d5e524bdc2d25448b4571",
            _tpl: "560d5e524bdc2d25448b4571",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x707buckshot);
        assortTable.barter_scheme["560d5e524bdc2d25448b4571"] = [
            [
                {
                    count: 17
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 6.5mm Express Buckshot
        const vaf12x7065expressbuckshot: Item = {
            _id: "5d6e67fba4b9361bc73bc779",
            _tpl: "5d6e67fba4b9361bc73bc779",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x7065expressbuckshot);
        assortTable.barter_scheme["5d6e67fba4b9361bc73bc779"] = [
            [
                {
                    count: 22
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Piranha
        const vaf12x70piranha: Item = {
            _id: "64b8ee384b75259c590fa89b",
            _tpl: "64b8ee384b75259c590fa89b",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70piranha);
        assortTable.barter_scheme["64b8ee384b75259c590fa89b"] = [
            [
                {
                    count: 123
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Flechette
        const vaf12x70flechette: Item = {
            _id: "5d6e6911a4b9361bd5780d52",
            _tpl: "5d6e6911a4b9361bd5780d52",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70flechette);
        assortTable.barter_scheme["5d6e6911a4b9361bd5780d52"] = [
            [
                {
                    count: 187
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 12x70MM SLUG
        // RIP
        const vaf12x70ripslug: Item = {
            _id: "5c0d591486f7744c505b416f",
            _tpl: "5c0d591486f7744c505b416f",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70ripslug);
        assortTable.barter_scheme["5c0d591486f7744c505b416f"] = [
            [
                {
                    count: 392
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SuperFormance HP Slug
        const vaf12x70superformance: Item = {
            _id: "5d6e68d1a4b93622fe60e845",
            _tpl: "5d6e68d1a4b93622fe60e845",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70superformance);
        assortTable.barter_scheme["5d6e68d1a4b93622fe60e845"] = [
            [
                {
                    count: 108
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Grizzly 40 Slug
        const vaf12x70grizzly40: Item = {
            _id: "5d6e6869a4b9361c140bcfde",
            _tpl: "5d6e6869a4b9361c140bcfde",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70grizzly40);
        assortTable.barter_scheme["5d6e6869a4b9361c140bcfde"] = [
            [
                {
                    count: 37
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Copper Sabot HP Slug
        const vaf12x70coppersabot: Item = {
            _id: "5d6e68b3a4b9361bca7e50b5",
            _tpl: "5d6e68b3a4b9361bca7e50b5",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70coppersabot);
        assortTable.barter_scheme["5d6e68b3a4b9361bca7e50b5"] = [
            [
                {
                    count: 46
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Lead Slug
        const vaf12x70leadslug: Item = {
            _id: "58820d1224597753c90aeb13",
            _tpl: "58820d1224597753c90aeb13",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70leadslug);
        assortTable.barter_scheme["58820d1224597753c90aeb13"] = [
            [
                {
                    count: 31
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Dual Sabot Slug
        const vaf12x70dualsabot: Item = {
            _id: "5d6e68dea4b9361bcc29e659",
            _tpl: "5d6e68dea4b9361bcc29e659",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70dualsabot);
        assortTable.barter_scheme["5d6e68dea4b9361bcc29e659"] = [
            [
                {
                    count: 38
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Poleva-3" Slug
        const vaf12x70poleva3slug: Item = {
            _id: "5d6e6891a4b9361bd473feea",
            _tpl: "5d6e6891a4b9361bd473feea",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70poleva3slug);
        assortTable.barter_scheme["5d6e6891a4b9361bd473feea"] = [
            [
                {
                    count: 29
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FTX Custom Lite Slug
        const vaf12x70ftxslug: Item = {
            _id: "5d6e68e6a4b9361c140bcfe0",
            _tpl: "5d6e68e6a4b9361c140bcfe0",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70ftxslug);
        assortTable.barter_scheme["5d6e68e6a4b9361c140bcfe0"] = [
            [
                {
                    count: 40
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Poleva-6U" Slug
        const vaf12x70poleva6uslug: Item = {
            _id: "5d6e689ca4b9361bc8618956",
            _tpl: "5d6e689ca4b9361bc8618956",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70poleva6uslug);
        assortTable.barter_scheme["5d6e689ca4b9361bc8618956"] = [
            [
                {
                    count: 38
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Makeshift .50 BMG Slug
        const vaf12x7050bmgslug: Item = {
            _id: "5d6e68c4a4b9361b93413f79",
            _tpl: "5d6e68c4a4b9361b93413f79",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x7050bmgslug);
        assortTable.barter_scheme["5d6e68c4a4b9361b93413f79"] = [
            [
                {
                    count: 224
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP-20 Armor-Piercing Slug
        const vaf12x70ap20slug: Item = {
            _id: "5d6e68a8a4b9360b6c0d54e2",
            _tpl: "5d6e68a8a4b9360b6c0d54e2",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf12x70ap20slug);
        assortTable.barter_scheme["5d6e68a8a4b9360b6c0d54e2"] = [
            [
                {
                    count: 498
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 20x70MM
        // 5.6mm Buckshot
        const vaf20x7056buckshot: Item = {
            _id: "5d6e695fa4b936359b35d852",
            _tpl: "5d6e695fa4b936359b35d852",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x7056buckshot);
        assortTable.barter_scheme["5d6e695fa4b936359b35d852"] = [
            [
                {
                    count: 11
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 6.2mm Buckshot
        const vaf20x7062buckshot: Item = {
            _id: "5d6e69b9a4b9361bc8618958",
            _tpl: "5d6e69b9a4b9361bc8618958",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x7062buckshot);
        assortTable.barter_scheme["5d6e69b9a4b9361bc8618958"] = [
            [
                {
                    count: 17
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 7.5mm Buckshot
        const vaf20x7075buckshot: Item = {
            _id: "5a38ebd9c4a282000d722a5b",
            _tpl: "5a38ebd9c4a282000d722a5b",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x7075buckshot);
        assortTable.barter_scheme["5a38ebd9c4a282000d722a5b"] = [
            [
                {
                    count: 13
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 7.3mm Buckshot
        const vaf20x7073buckshot: Item = {
            _id: "5d6e69c7a4b9360b6c0d54e4",
            _tpl: "5d6e69c7a4b9360b6c0d54e4",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x7073buckshot);
        assortTable.barter_scheme["5d6e69c7a4b9360b6c0d54e4"] = [
            [
                {
                    count: 21
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Devastator Slug
        const vaf20x70devastatorslug: Item = {
            _id: "5d6e6a5fa4b93614ec501745",
            _tpl: "5d6e6a5fa4b93614ec501745",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x70devastatorslug);
        assortTable.barter_scheme["5d6e6a5fa4b93614ec501745"] = [
            [
                {
                    count: 101
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Poleva-3" Slug
        const vaf20x70poleva3slug: Item = {
            _id: "5d6e6a53a4b9361bd473feec",
            _tpl: "5d6e6a53a4b9361bd473feec",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x70poleva3slug);
        assortTable.barter_scheme["5d6e6a53a4b9361bd473feec"] = [
            [
                {
                    count: 27
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Star Slug
        const vaf20x70starslug: Item = {
            _id: "5d6e6a05a4b93618084f58d0",
            _tpl: "5d6e6a05a4b93618084f58d0",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x70starslug);
        assortTable.barter_scheme["5d6e6a05a4b93618084f58d0"] = [
            [
                {
                    count: 45
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Poleva-6U" Slug
        const vaf20x70poleva6uslug: Item = {
            _id: "5d6e6a42a4b9364f07165f52",
            _tpl: "5d6e6a42a4b9364f07165f52",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf20x70poleva6uslug);
        assortTable.barter_scheme["5d6e6a42a4b9364f07165f52"] = [
            [
                {
                    count: 36
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 23x75MM
        // "Zveda" Flashbang Round
        const vaf23x75zveda: Item = {
            _id: "5e85a9f4add9fe03027d9bf1",
            _tpl: "5e85a9f4add9fe03027d9bf1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf23x75zveda);
        assortTable.barter_scheme["5e85a9f4add9fe03027d9bf1"] = [
            [
                {
                    count: 549
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Shrapnel-25" Buckshot
        const vaf23x75shrapnel25: Item = {
            _id: "5f647f31b6238e5dd066e196",
            _tpl: "5f647f31b6238e5dd066e196",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf23x75shrapnel25);
        assortTable.barter_scheme["5f647f31b6238e5dd066e196"] = [
            [
                {
                    count: 54
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Shrapnel-10" Buckshot
        const vaf23x75shrapnel10: Item = {
            _id: "5e85a9a6eacf8c039e4e2ac1",
            _tpl: "5e85a9a6eacf8c039e4e2ac1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf23x75shrapnel10);
        assortTable.barter_scheme["5e85a9a6eacf8c039e4e2ac1"] = [
            [
                {
                    count: 44
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // "Barrikda" Slug
        const vaf23x75barrikda: Item = {
            _id: "5e85aa1a988a8701445df1f5",
            _tpl: "5e85aa1a988a8701445df1f5",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf23x75barrikda);
        assortTable.barter_scheme["5e85aa1a988a8701445df1f5"] = [
            [
                {
                    count: 143
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 9x18MM MAKAROV
        // SP8 GZH
        const vaf9x18sp8: Item = {
            _id: "5737218f245977612125ba51",
            _tpl: "5737218f245977612125ba51",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18sp8);
        assortTable.barter_scheme["5737218f245977612125ba51"] = [
            [
                {
                    count: 39
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SP7 GZH
        const vaf9x18sp7: Item = {
            _id: "57372140245977611f70ee91",
            _tpl: "57372140245977611f70ee91",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18sp7);
        assortTable.barter_scheme["57372140245977611f70ee91"] = [
            [
                {
                    count: 94
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PSV
        const vaf9x18psv: Item = {
            _id: "5737207f24597760ff7b25f2",
            _tpl: "5737207f24597760ff7b25f2",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18psv);
        assortTable.barter_scheme["5737207f24597760ff7b25f2"] = [
            [
                {
                    count: 41
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // P GZH
        const vaf9x18pgzh: Item = {
            _id: "573719762459775a626ccbc1",
            _tpl: "573719762459775a626ccbc1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18pgzh);
        assortTable.barter_scheme["573719762459775a626ccbc1"] = [
            [
                {
                    count: 7
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PSO GZH
        const vaf9x18psogzh: Item = {
            _id: "57371f8d24597761006c6a81",
            _tpl: "57371f8d24597761006c6a81",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18psogzh);
        assortTable.barter_scheme["57371f8d24597761006c6a81"] = [
            [
                {
                    count: 12
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS GS PPO
        const vaf9x18psgsppo: Item = {
            _id: "57371f2b24597761224311f1",
            _tpl: "57371f2b24597761224311f1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18psgsppo);
        assortTable.barter_scheme["57371f2b24597761224311f1"] = [
            [
                {
                    count: 16
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PRS GS
        const vaf9x18prsgs: Item = {
            _id: "57371eb62459776125652ac1",
            _tpl: "57371eb62459776125652ac1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18prsgs);
        assortTable.barter_scheme["57371eb62459776125652ac1"] = [
            [
                {
                    count: 22
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PPE GZH
        const vaf9x18ppegzh: Item = {
            _id: "57371b192459775a9f58a5e0",
            _tpl: "57371b192459775a9f58a5e0",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18ppegzh);
        assortTable.barter_scheme["57371b192459775a9f58a5e0"] = [
            [
                {
                    count: 29
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PPT GZH
        const vaf9x18pptgzh: Item = {
            _id: "57371e4124597760ff7b25f1",
            _tpl: "57371e4124597760ff7b25f1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18pptgzh);
        assortTable.barter_scheme["57371e4124597760ff7b25f1"] = [
            [
                {
                    count: 24
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PST GZH
        const vaf9x18pstgzh: Item = {
            _id: "5737201124597760fc4431f1",
            _tpl: "5737201124597760fc4431f1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18pstgzh);
        assortTable.barter_scheme["5737201124597760fc4431f1"] = [
            [
                {
                    count: 25
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // RG028 GZH
        const vaf9x18rg028gzh: Item = {
            _id: "573720e02459776143012541",
            _tpl: "573720e02459776143012541",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18rg028gzh);
        assortTable.barter_scheme["573720e02459776143012541"] = [
            [
                {
                    count: 48
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BZHT GZH
        const vaf9x18bzhtgzh: Item = {
            _id: "573718ba2459775a75491131",
            _tpl: "573718ba2459775a75491131",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18bzhtgzh);
        assortTable.barter_scheme["573718ba2459775a75491131"] = [
            [
                {
                    count: 36
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PSTM GZH
        const vaf9x18pstmgzh: Item = {
            _id: "57371aab2459775a77142f22",
            _tpl: "57371aab2459775a77142f22",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18pstmgzh);
        assortTable.barter_scheme["57371aab2459775a77142f22"] = [
            [
                {
                    count: 64
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PBM GZH
        const vaf9x18pbmgzh: Item = {
            _id: "573719df2459775a626ccbc2",
            _tpl: "573719df2459775a626ccbc2",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x18pbmgzh);
        assortTable.barter_scheme["573719df2459775a626ccbc2"] = [
            [
                {
                    count: 68
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 7.62x25MM TOKAREV
        // LRNPC
        const vaf762x25lrnpc: Item = {
            _id: "573602322459776445391df1",
            _tpl: "573602322459776445391df1",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25lrnpc);
        assortTable.barter_scheme["573602322459776445391df1"] = [
            [
                {
                    count: 38
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // LRN
        const vaf762x25lrn: Item = {
            _id: "573601b42459776410737435",
            _tpl: "573601b42459776410737435",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25lrn);
        assortTable.barter_scheme["573601b42459776410737435"] = [
            [
                {
                    count: 27
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ43
        const vaf762x25fmj43: Item = {
            _id: "5735ff5c245977640e39ba7e",
            _tpl: "5735ff5c245977640e39ba7e",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25fmj43);
        assortTable.barter_scheme["5735ff5c245977640e39ba7e"] = [
            [
                {
                    count: 28
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AKBS
        const vaf762x25akbs: Item = {
            _id: "5735fdcd2459776445391d61",
            _tpl: "5735fdcd2459776445391d61",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25akbs);
        assortTable.barter_scheme["5735fdcd2459776445391d61"] = [
            [
                {
                    count: 27
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // P GL
        const vaf762x25pgl: Item = {
            _id: "5736026a245977644601dc61",
            _tpl: "5736026a245977644601dc61",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25pgl);
        assortTable.barter_scheme["5736026a245977644601dc61"] = [
            [
                {
                    count: 29
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PT GZH
        const vaf762x25ptgzh: Item = {
            _id: "573603c924597764442bd9cb",
            _tpl: "573603c924597764442bd9cb",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25ptgzh);
        assortTable.barter_scheme["573603c924597764442bd9cb"] = [
            [
                {
                    count: 35
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PST GZH
        const vaf762x25pstgzh: Item = {
            _id: "573603562459776430731618",
            _tpl: "573603562459776430731618",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf762x25pstgzh);
        assortTable.barter_scheme["573603562459776430731618"] = [
            [
                {
                    count: 39
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 9x19MM PARABELLUM
        // RIP
        const vaf9x19rip: Item = {
            _id: "5c0d56a986f774449d5de529",
            _tpl: "5c0d56a986f774449d5de529",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x19rip);
        assortTable.barter_scheme["5c0d56a986f774449d5de529"] = [
            [
                {
                    count: 236
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Quakemaker
        const vaf9x19quakemaker: Item = {
            _id: "5efb0e16aeb21837e749c7ff",
            _tpl: "5efb0e16aeb21837e749c7ff",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x19quakemaker);
        assortTable.barter_scheme["5efb0e16aeb21837e749c7ff"] = [
            [
                {
                    count: 168
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PSO GZH
        const vaf9x19psogzh: Item = {
            _id: "58864a4f2459770fcc257101",
            _tpl: "58864a4f2459770fcc257101",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x19psogzh);
        assortTable.barter_scheme["58864a4f2459770fcc257101"] = [
            [
                {
                    count: 27
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Luger CCI
        const vaf9x19lugercci: Item = {
            _id: "5a3c16fe86f77452b62de32a",
            _tpl: "5a3c16fe86f77452b62de32a",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(vaf9x19lugercci);
        assortTable.barter_scheme["5a3c16fe86f77452b62de32a"] = [
            [
                {
                    count: 95
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // GT GZH
        const vaf525buckshot: Item = {
            _id: "5c3df7d588a4501f290594e5",
            _tpl: "5c3df7d588a4501f290594e5",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5c3df7d588a4501f290594e5"] = [
            [
                {
                    count: 40
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M882
        64b7bbb74b75259c590fa897
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PST GZH
        56d59d3ad2720bdb418b4577
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP 6.3
        5c925fa22e221601da359b7b
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PBP GZH
        5efb0da7a29a85116f6ea05f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // .45 ACP
        // RIP
        5ea2a8e200685063ec28c05a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Hydra-Shok
        5efb0fc6aeb21837e749c801
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Lasermatch FMJ
        5efb0d4f4bc50b58e81710f3
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Match FMJ
        5e81f423763d9f754677bf2e
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP
        5efb0cabfb3e451d70735af5
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 9x21MM
        // PE GZH
        5a26ac06c4a282000c5a90a8
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // P GZH
        5a26abfac4a28232980eabff
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS GZH
        5a269f97c4a282000b151807
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BT GZH
        5a26ac0ec4a28200741e1e18
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // .357 MAGNUM
        // SP
        62330c40bdd19b369e1e53d1
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // HP
        62330bfadc5883093563729b
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // JHP
        62330c18744e5e31df12f516
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        62330b3ed4dc74626d570b95
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 5.7x28MM
        // R37.F
        5cc86832d7f00c000d3a6e6c
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // F37.X
        5cc86840d7f00c002412c56c
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SS198LF
        5cc80f79e4a949033c7343b2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SS197SR
        5cc80f8fe4a949033b0224a2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SB193
        5cc80f67e4a949035e43bbba
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // L191
        5cc80f53e4a949000e1ea4f8
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SS190
        5cc80f38e4a949001152b560
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 4.6x30MM
        // Action SX
        5ba26812d4351e003201fef1
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // Subsonic SX
        5ba26844d4351e00334c9475
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // JSP SX
        64b6979341772715af0f9c39
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ SX
        5ba2678ad4351e44f824b344
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP SX
        5ba26835d4351e0035628ff5
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 9x39MM
        // FMJ
        // SP-5 GS
        57a0dfb82459774d3078b56c
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SPP GS
        5c0d668f86f7747ccb7f13b2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PAB-9 GS
        61962d879bb3d20b0946d385
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SP-6 GS
        57a0e5022459774d1673f889
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BP GS
        5c0d688c86f77413ae3407b2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // .366 TKM
        // Geska
        59e6658b86f77411d949b250
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        59e6542b86f77411dc52a77a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // EKO
        59e655cb86f77411dc52a77b
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP-M
        5f0596629e22f464da6bbdd9
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 5.45x39MM
        // HP
        56dff216d2720bbd668b4568
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PRS GS
        56dff338d2720bbd668b4569
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SP
        56dff421d2720b5f5a8b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // US GS
        56dff4ecd2720b5f5a8b4568
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // T GS
        56dff4a2d2720bbd668b456a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        56dff0bed2720bb0668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS GS
        56dff3afd2720bba668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PP GS
        56dff2ced2720bb4668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BT GS
        56dff061d2720bb5668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // 7N40
        61962b617c6c7b169525f168
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BP GS
        56dfef82d2720bbd668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BS GS
        56dff026d2720bb8668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PPBS GS "Igolnik"
        5c0d5e4486f77478390952fe
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 5.56x45MM
        // Warmageddon
        5c0d5ae286f7741e46554302
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // HP
        59e6927d86f77411da468256
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // MK.255 MOD.0 (RRLP)
        59e6918f86f7746c9f75e849
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M856
        59e68f6f86f7746c9f75e846
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        59e6920f86f77411d82aa167
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M855
        54527a984bdc2d4e668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // MK.318 MOD.0 (SOST)
        60194943740c5d77f6705eea
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M856A1
        59e6906286f7746c9f75e847
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M855A1
        54527ac44bdc2d36668b4567
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M995
        59e690b686f7746c9f75e848
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SSA AP
        601949593ae8f707c4608daa
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 7.62x39MM
        // HP
        59e4d3d286f774176a36250a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SP
        64b7af734b75259c590fa895
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        64b7af5a8532cf95ee0a0dbd
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // US GZH
        59e4d24686f7741776641ac7
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // T-45M1 GZH
        59e4cf5286f7741778269d8a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS GZH
        5656d7c34bdc2d9d198b4587
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PP
        64b7af434b75259c590fa893
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BP GZH
        59e0d99486f7744a32234762
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // MAI AP
        601aa3d2b2bcb34913271e6d
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // .300 BLACKOUT
        // Whisper
        6196365d58ef8c428c287da1
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // V-Max
        6196364158ef8c428c287d9f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BCP FMJ
        5fbe3ffdf8b6a877a729ea82
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M62 Tracer
        619636be6db0f2477964e710
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // CBJ
        64b8725c4b75259c590fa899
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP
        5fd20ff893a8961fc660a954
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 7.62x51MM
        // Ultra Nosler
        5e023e88277cce2b522ff2b1
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // TCW SP
        5e023e6e34d52a55c3304f71
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BCP FMJ
        5e023e53d4353e3302577c4c
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M80
        58dd3ad986f77403051cba8f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M62 TRACER
        5a608bf24f39f98ffc77720e
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M61
        5a6086ea4f39f99cd479502f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // M993
        5efb0c1bd79ff02a1f5e68d9
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 7.62x54R
        // HB BT
        64b8f7c241772715af0f9c3d
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SP BT
        64b8f7b5389d7ffd620ccba2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        64b8f7968532cf95ee0a0dbf
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // T-46M GZH
        5e023cf8186a883be655e54f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // LPS GZH
        5887431f2459777e1612938f
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS GZH
        59e77a2386f7742ee578960a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BT GZH
        5e023d34e8a400319a28ed44
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // SNB GZH
        560d61e84bdc2da74d8b4571
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // BS GS
        5e023d48186a883be655e551
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // 12.7x55MM
        // PS12A
        5cadf6e5ae921500113bb973
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS12
        5cadf6ddae9215051e1c23b2
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // PS12B
        5cadf6eeae921500134b2799
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];

        // .338 LAPUA MAGNUM
        // TAX-X
        5fc382b6d6fa9c00c571bbc3
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // UCW
        5fc382c1016cce60e8341b20
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // FMJ
        5fc275cf85fd526b824a571a
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
        // AP
        5fc382a9d724d907e2077dab
        const vaf525buckshot: Item = {
            _id: "5d6e6772a4b936088465b17c",
            _tpl: "5d6e6772a4b936088465b17c",
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(newsuper12g);
        assortTable.barter_scheme["5d6e6772a4b936088465b17c"] = [
            [
                {
                    count: 20
                    _tpl: ROUBLE_ID
                }
            ]
        ];
    }
    private pushTableItem(tableID: string, itemID: string, price: int) {
        const tableID: Item = {
            _id: itemID,
            _tpl: itemID,
            parentId: "hideout",
            slotId: "hideout",
            upd: {
                UnlimitedCount: true,
                StackObjectsCount: 999999999
            }
        };
        assortTable.items.push(tableID);
        assortTable.barter_scheme[itemID] = [
            [
                {
                    count: price
                    _tpl: ROUBLE_ID
                }
            ]
        ]
    }
}